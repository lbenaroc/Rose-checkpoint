exports.handler = async (event) => {
    const stage = event.requestContext.stage;
    const now = new Date().toISOString();
    return {
      statusCode: 200,
      body: JSON.stringify({
        stage: stage,
        time: now
      })
    };
  };
  