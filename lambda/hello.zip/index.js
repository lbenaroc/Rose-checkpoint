exports.handler = async (event) => {
    const stage = event.requestContext.stage;
    return {
      statusCode: 200,
      body: JSON.stringify({ message: `Hello from ${stage}!` })
    };
  };
  